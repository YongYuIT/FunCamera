package com.thinking.testcamera;

import android.app.Activity;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.hardware.Camera.Face;
import android.hardware.Camera.FaceDetectionListener;
import android.hardware.Camera.PreviewCallback;
import android.os.Bundle;
import android.util.Log;
import android.view.TextureView;
import android.view.TextureView.SurfaceTextureListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import java.io.IOException;


public class MainActivity extends Activity implements PreviewCallback {

    Button mButton;
    TextureView mTextureView;
    Camera mCamera;
    byte buf[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mTextureView = (TextureView) findViewById(R.id.card_dvr_preview);
        mTextureView.setSurfaceTextureListener(new SurfaceTextureListener() {
            @Override
            public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
                startPreview(surface);
            }

            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
                release();
                return false;
            }

            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
            }

            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture arg0) {
            }
        });


        mButton = (Button) findViewById(R.id.Check);
        mButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }


    public void startPreview(SurfaceTexture surface) {
        try {
            mCamera = Camera.open(0);
        } catch (Exception e) {
            return;
        }

        if (mCamera != null) {
        } else {
            return;
        }
        mCamera.setDisplayOrientation(0);
        try {
            buf = new byte[1024 * 480 * 4 * 10];
            Log.i("yuyong", "startPreview-->" + buf.hashCode());
            mCamera.addCallbackBuffer(buf);
            mCamera.setPreviewCallbackWithBuffer(this);
            mCamera.setPreviewTexture(surface);
            mCamera.setFaceDetectionListener(new FaceDetectionListener() {
                @Override
                public void onFaceDetection(Face[] faces, Camera camera) {
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
        mCamera.startPreview();

    }

    public void release() {
        if (mCamera != null) {
            mCamera.stopPreview();
            mCamera.release();
            mCamera = null;
        }
    }

    @Override
    public void onPreviewFrame(byte[] data, Camera camera) {
        Log.i("yuyong", "onPreviewFrame-->" + data.hashCode() + "-->" + buf.hashCode());
        camera.addCallbackBuffer(data);
    }
}

